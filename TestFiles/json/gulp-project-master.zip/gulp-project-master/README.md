# Gulp Project (ENG)
This project I made specifically for the ability to quickly build the project, using technology sass, gulp, npm-server and other ...

After cloning the repository needs to be done
```sh
$ bower i && npm i
```
Then just need to run the command
```sh
$ gulp
```
Nice work...

---
# Gulp Project (RUS)

Этот проект я сделал специально для возможности быстро собирать проект, использую технологии sass, gulp, npm-server и прочее...

После клонирования репозитория необходимо сделать
```sh
$ bower i && npm i
```
Потом останется только запустить команду 
```sh
$ gulp
```
Приятной работы...

---
# What Gulp Modules I Use
