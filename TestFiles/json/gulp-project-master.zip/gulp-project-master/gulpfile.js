var requireDir = require('require-dir');
var tasks = requireDir('./tasks');